import LoopinSync from "@/components/LoopinSync";

export default function Home() {
  return <LoopinSync />;
}
